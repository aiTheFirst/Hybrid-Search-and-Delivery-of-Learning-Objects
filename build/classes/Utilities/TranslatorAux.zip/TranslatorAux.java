/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fullLomTranslator;

/**
 *
 * @author Jarrett
 */
public class TranslatorAux extends Thread {

    public Translator t = null;
    public String repoDir = null;


    public void run(){
        try{
            Translator.main(new String[] {repoDir});
        }
        catch(Exception e){
            //oops. give up.
            return;
        }
    }

}
