/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fullLomTranslator;

import java.io.*;
import java.util.*;

/**
 *
 * @author Jarrett G. Steele
 * August 2009
 *
 * At this point in the invoker project, an issue exists with the format of xml lom files
 * The crawler outputs what I call "full xml lom" - the xml files have many tags and attributes, as obtained from needs.org
 * The LOSearch program was written to use only plain text files containing only the abstract portion of the full xml lom.
 * The Personalization program was written to use what I call "simplified" xml lom - xml files having fewer tags and attributes when compared to the full xml lom.
 *
 * To solve the disconnect between xml lom format among these processes, I've contiuned the hackery with a translator that will convert full xml lom into both plain text abstracts, and simplified xml lom. thus satisfing each program.
 *
 *
 *
 */
public class FullLomTranslator extends Thread {

    public void run(){
        try{
            this.main(null);
        }
        catch(Exception e){
            //oops. give up.
            return;
        }
    }

    /*
     * args[0] = directory of full xml loms
     */
    public static void main(String[] args) throws Exception {  // exceptions bound to happen.
        //open the directory
        File dir = new File(args[0]);

        //get list of files.
        String[] filenames = dir.list();

        //for each full xml file in this repo directory, do translation into both plain abstract text, and simplified xml lom.
        for(int i = 0; i < filenames.length; i++){
            doTranslationToPlainTextAbstraction(filenames[i],args[0]);
        }


    }

    public static void test(){

    }

    // utility to return the name of the xml tag's attribute
    public static String getAttributeName(String xmlLine){
        StringTokenizer st = new StringTokenizer(xmlLine,"<:> ");
        st.nextToken(); // skip open bracket "<"
        st.nextToken(); // always be "lom"
        st.nextToken(); // skip ":"
        return st.nextToken(); //return the attribute name.
    }

    /* An XML parser would be more appropriate, but its simple enough to just use java io. */
    public static void doTranslationToPlainTextAbstraction(String filename,String directory) throws Exception{
        // read until found abstract tag, copy text until ending tag, done.

        Stack stack = new Stack();

        BufferedReader in = new BufferedReader(new FileReader(directory + "\\" + filename));
        StringTokenizer st = null;

        if( in == null) return;

        String line = null;
        line = in.readLine();
        st = new StringTokenizer(line,"<:>? ", true);

        while(st.hasMoreTokens()){ // parse out the <?xml ... ?> stuff
            if( st.nextToken().equals("?")){
                if( st.nextToken().equals(">")){
                    //end of the version and encoding stuff.
                    break;
                }
            }
        }

        if( st.countTokens() == 0) line = in.readLine();

        



        
    }

}
